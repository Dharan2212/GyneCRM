/**
 * GyneCRM — Layout Components Barrel Export
 *
 * Import from:
 *   import { Sidebar, Header, NavItem, Breadcrumbs } from '@components/layout';
 */

export { Sidebar, MobileSidebar } from './Sidebar';
export { Header }                 from './Header';
export { NavItem, NavIcon }       from './NavItem';
export { Breadcrumbs }            from './Breadcrumbs';
